#!/bin/bash


echo "chatur: Adarniya senapati mahodaya"
echo "chatur: aaj ham sab milke chamatkar karenge"
echo "rancho: ratta marega to aise hi hoga"
echo "chatur: thuchuk thuchuk"
echo "rancho: file banake dikha"

mkdir -p rancho

echo "rancho: le bana diya folder"
echo "chatur: ab file banake dikha"

echo "le bana di file" >ranchoFile.txt

